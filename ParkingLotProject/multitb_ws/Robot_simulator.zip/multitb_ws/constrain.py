import rclpy
from rclpy.node import Node
from gazebo_msgs.srv import SpawnEntity, SetEntityState
from gazebo_msgs.msg import ModelState
from geometry_msgs.msg import Pose

class AttachSUVNode(Node):

    def __init__(self):
        super().__init__('attach_suv_node')
        
        self.spawn_client = self.create_client(SpawnEntity, '/spawn_entity')
        self.set_state_client = self.create_client(SetEntityState, '/gazebo/set_model_state')

        self.get_logger().info('Attempting to spawn SUV...')
        self.spawn_suv()

        self.get_logger().info('Moving turtlebot under SUV...')
        self.move_turtlebot_under_suv()


    def spawn_suv(self):
        while not self.spawn_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Spawn service not available, waiting...')

        request = SpawnEntity.Request()
        request.name = 'SUV'
        request.xml = """<sdf version="1.6">
                          <model name='SUV'>
                            <link name='base_link'>
                              <pose>0 0 0.5 0 0 0</pose>
                              <visual name='visual'>
                                <geometry>
                                  <box>
                                    <size>1 0.6 0.5</size> 
                                  </box>
                                </geometry>
                              </visual>
                            </link>
                          </model>
                          </sdf>"""
        request.initial_pose = Pose()
        request.initial_pose.position.x = 0.0
        request.initial_pose.position.y = 0.0
        request.initial_pose.position.z = 0.5

        future = self.spawn_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        if future.result() is not None:
            self.get_logger().info('SUV successfully spawned!')
        else:
            self.get_logger().error('Failed to spawn SUV')


    def move_turtlebot_under_suv(self):
        while not self.set_state_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Set state service not available, waiting...')

        turtlebot_state = ModelState()
        turtlebot_state.model_name = 'turtlebot3_waffle'
        turtlebot_state.pose.position.x = 0.0
        turtlebot_state.pose.position.y = 0.0
        turtlebot_state.pose.position.z = 0.0

        future = self.set_state_client.call_async(turtlebot_state)
        rclpy.spin_until_future_complete(self, future)

        if future.result() is not None:
            self.get_logger().info('Successfully moved turtlebot under SUV')
        else:
            self.get_logger().error('Failed to move turtlebot')


def main(args=None):
    rclpy.init(args=args)
    node = AttachSUVNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down attach_suv_node')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
