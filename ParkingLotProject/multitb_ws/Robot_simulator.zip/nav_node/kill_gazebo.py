import os
import signal
import subprocess

def kill_gazebo_processes():
    # Gazebo 관련 프로세스 이름
    processes_to_kill = ["gazebo", "gzserver", "gzclient"]

    for process_name in processes_to_kill:
        try:
            # 실행 중인 프로세스 검색
            output = subprocess.check_output(["pgrep", "-f", process_name], text=True)
            pids = output.strip().split("\n")
            
            # 프로세스 종료
            for pid in pids:
                os.kill(int(pid), signal.SIGKILL)
                print(f"Killed {process_name} process with PID {pid}")
        except subprocess.CalledProcessError:
            print(f"No {process_name} processes found")

if __name__ == "__main__":
    kill_gazebo_processes()

