import sys
import time
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QVBoxLayout, QWidget


class TimeTracker(QWidget):
    def __init__(self):
        super().__init__()
        self.status = None
        self.start_time = None
        self.elapsed_time = 0
        self.track_start_time = None
        self.track_elapsed_time = 0

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        self.time_label = QLabel('단속 전', self)
        layout.addWidget(self.time_label)

        self.st1_button = QPushButton('단속 종료', self)
        self.st1_button.clicked.connect(self.on_st1_click)
        layout.addWidget(self.st1_button)

        self.st2_button = QPushButton('단속 시작', self)
        self.st2_button.clicked.connect(self.on_st2_click)
        layout.addWidget(self.st2_button)

        self.st3_button = QPushButton('추적 시작', self)
        self.st3_button.clicked.connect(self.on_st3_click)
        layout.addWidget(self.st3_button)

        self.setLayout(layout)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)

    def on_st1_click(self):
        self.status = '단속 전'
        self.elapsed_time = 0
        self.start_time = None
        self.track_elapsed_time = 0
        self.track_start_time = None
        self.update_time_display()

    def on_st2_click(self):
        if self.status != '단속 중':
            self.status = '단속 중'
            if self.start_time is None:
                self.start_time = time.time()
        self.update_time_display()

    def on_st3_click(self):
        self.status = '추적 중'
        self.track_start_time = time.time()
        self.track_elapsed_time = 0
        self.update_time_display()

    def update_time(self):
        if self.status == '단속 중' and self.start_time:
            self.elapsed_time = int(time.time() - self.start_time)
        
        if self.status == '추적 중' and self.track_start_time:
            self.track_elapsed_time = int(time.time() - self.track_start_time)
        
        self.update_time_display()

    def update_time_display(self):
        if self.status == '단속 중':
            formatted_time = self.format_time(self.elapsed_time)
            start_time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.start_time))
            self.time_label.setText(f"단속 시작 시각: {start_time_str}\n단속 경과 시간: {formatted_time}")
        elif self.status == '추적 중':
            formatted_time = self.format_time(self.track_elapsed_time)
            start_time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.track_start_time)) if self.track_start_time else "--:--:--"
            self.time_label.setText(f"추적 시작 시각: {start_time_str}\n추적 경과 시간: {formatted_time}")
        else:
            current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
            self.time_label.setText(f"현재 시각: {current_time} \n단속 전")

    def format_time(self, elapsed_seconds):
        hours = elapsed_seconds // 3600
        minutes = (elapsed_seconds % 3600) // 60
        seconds = elapsed_seconds % 60
        return f"{hours:02}:{minutes:02}:{seconds:02}"


class App(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("시간 추적 시스템")
        self.resize(500, 600)

        self.time_tracker = TimeTracker()
        self.setCentralWidget(self.time_tracker)
        
        self.center()
    
    def center(self):
        screen = QApplication.primaryScreen().geometry()
        size = self.geometry()
        self.move((screen.width() - size.width()) // 2, (screen.height() - size.height()) // 2)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_app = App()
    main_app.show()
    sys.exit(app.exec_())
