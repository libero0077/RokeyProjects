# db_utils.py

import mysql.connector
from PyQt5.QtWidgets import QMessageBox

def get_db_connection():
    """MySQL 데이터베이스 연결 설정"""
    try:
        return mysql.connector.connect(
            host="127.0.0.1",  # MySQL 서버 주소
            user="log_manager",  # MySQL 사용자 이름
            password="0000",  # MySQL 비밀번호
            database="logs"  # 데이터베이스 이름
        )
    except mysql.connector.Error as e:
        QMessageBox.critical(None, "Database Error", f"Failed to connect to the database:\n{e}")
        return None

def fetch_table_data(table_name):
    """MySQL 테이블 데이터 가져오기"""
    connection = get_db_connection()
    if connection is None:
        return [], []
    cursor = connection.cursor()
    try:
        cursor.execute(f"SELECT * FROM {table_name}")
        columns = [column[0] for column in cursor.description]  # 컬럼 이름 가져오기
        rows = cursor.fetchall()  # 데이터 가져오기
    except mysql.connector.Error as e:
        QMessageBox.critical(None, "Query Error", f"Failed to fetch data:\n{e}")
        columns, rows = [], []
    finally:
        connection.close()
    return columns, rows
