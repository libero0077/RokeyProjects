import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QTableWidget, QTableWidgetItem
import mysql.connector

# MySQL 데이터베이스 연결 설정
def get_db_connection():
    return mysql.connector.connect(
        host="127.0.0.1",  # MySQL 서버 주소
        user="log_manager",  # MySQL 사용자 이름
        password="0000",  # MySQL 비밀번호
        database="logs"  # 데이터베이스 이름
    )

# 데이터베이스에서 테이블 데이터를 읽어오는 함수
def fetch_table_data(table_name):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute(f"SELECT * FROM {table_name}")
    columns = [column[0] for column in cursor.description]  # 컬럼 이름 가져오기
    rows = cursor.fetchall()  # 데이터 가져오기
    connection.close()
    return columns, rows

# PyQt5 GUI
class DatabaseViewer(QMainWindow):
    def __init__(self, table_name):
        super().__init__()
        self.setWindowTitle("저장된 단속 로그")
        self.setGeometry(100, 100, 800, 600)

        # 테이블 데이터 가져오기
        self.table_name = table_name
        self.columns, self.data = fetch_table_data(table_name)

        # 중앙 위젯 설정
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # 테이블 위젯 생성 및 데이터 설정
        self.table_widget = QTableWidget()
        layout.addWidget(self.table_widget)
        self.load_data_into_table()

    def load_data_into_table(self):
        # 테이블 열 설정
        self.table_widget.setColumnCount(len(self.columns))
        self.table_widget.setHorizontalHeaderLabels(self.columns)

        # 테이블 데이터 설정
        self.table_widget.setRowCount(len(self.data))
        for row_index, row_data in enumerate(self.data):
            for col_index, col_data in enumerate(row_data):
                self.table_widget.setItem(row_index, col_index, QTableWidgetItem(str(col_data)))

# 메인 함수
def main():
    app = QApplication(sys.argv)

    # 표시할 MySQL 테이블 이름
    table_name = "escape_events"  # 테이블 이름 입력

    viewer = DatabaseViewer(table_name)
    viewer.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
