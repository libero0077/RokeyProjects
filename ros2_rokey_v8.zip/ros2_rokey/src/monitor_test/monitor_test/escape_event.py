from datetime import datetime
import mysql.connector

# MySQL 연결 설정
def get_db_connection():
    return mysql.connector.connect(
        host='localhost',      # MySQL 서버 주소
        user='log_manager',    # MySQL 사용자명
        password='0000',       # MySQL 비밀번호
        database='logs'        # 로그 데이터베이스
    )

# 도주 사건 발생 시 데이터베이스에 삽입
def log_escape_event_start(event_index):
    connection = get_db_connection()
    cursor = connection.cursor()

    start_time = datetime.now()  # 도주 발생 시각 (현재 시간)

    # SQL INSERT 쿼리
    insert_query = """
        INSERT INTO escape_events (event_index, start_time)
        VALUES (%s, %s)
    """

    # 데이터 삽입
    cursor.execute(insert_query, (event_index, start_time))
    connection.commit()

    # 연결 종료
    cursor.close()
    connection.close()
    print(f"도주 사건 시작: event_index={event_index}, start_time={start_time}")

# 도주 사건 종료 시 종료 시간을 업데이트
def log_escape_event_end(event_index):
    connection = get_db_connection()
    cursor = connection.cursor()

    end_time = datetime.now()  # 도주 종료 시각 (현재 시간)

    # SQL UPDATE 쿼리
    update_query = """
        UPDATE escape_events
        SET end_time = %s, status = %s
        WHERE event_index = %s
    """

    # 데이터 업데이트
    cursor.execute(update_query, (end_time, 'ended', event_index))
    connection.commit()

    # 연결 종료
    cursor.close()
    connection.close()
    print(f"도주 사건 종료: event_index={event_index}, end_time={end_time}")

# 예시: 도주 사건 발생 시 시작, 종료 시 종료
if __name__ == "__main__":
    event_index = 123  # 예시: 도주 차량의 고유 인덱스

    log_escape_event_start(event_index)

    # 도주 사건 종료
    log_escape_event_end(event_index)